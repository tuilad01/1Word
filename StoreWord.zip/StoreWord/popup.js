const elementWord = document.getElementById("pa--word"),
    elementMean = document.getElementById("pa--mean");

chrome.storage.sync.get('words', function(data) {
    if (data && data.words && data.words.length > 0) {
        document.getElementById("pa--total").innerText = data.words.length;
        elementWord.innerText = data.words.join(", ");
    } else {
        document.getElementById("pa--total").innerText = 0;
        elementWord.innerText = "Empty";
    }
});

chrome.storage.sync.get('means', function(data) {
    if (data && data.means && data.means.length > 0) {
        elementMean.innerText = data.means.join(", ");
    } else {
        elementMean.innerText = "Empty";
    }
});

const copyToClipboard = function(ele) {
    /* Get the text field */
    const copyText = document.createElement('textarea');
    copyText.setAttribute('readonly', '');
    copyText.style.position = 'absolute';
    copyText.style.left = '-9999px';
    document.body.appendChild(copyText);

    copyText.value = ele.innerText;
    /* Select the text field */
    copyText.select();

    /* Copy the text inside the text field */
    document.execCommand("copy");
    document.body.removeChild(copyText);

    document.getElementById("pa--notification").style.display = "block";
    setTimeout(() => {
        document.getElementById("pa--notification").style.display = "none";
    }, 2000);
    // document.getElementById("pa--notification").style.opacity = 1;
    //return copyText.value;    
}

const clearAll = function() {
    chrome.storage.sync.set({ words: [], means: [] });

    chrome.storage.sync.get('words', function(data) {
        if (data && data.words && data.words.length <= 0) {
            elementWord.innerText = "Empty";
        }
        return true;
    });
    chrome.storage.sync.get('means', function(data) {
        if (data && data.means && data.means.length <= 0) {
            elementMean.innerText = "Empty";
        }
        return true;
    });

    return true;
}

const onClick_clearAll = function() {
    showConfirm();
}

const showConfirm = function() {
    chrome.storage.sync.get('words', function(data) {
        if (data && data.words && data.words.length > 0) {
            chrome.storage.sync.get('means', function(data) {
                if (data && data.means && data.means.length > 0) {
                    document.getElementById("pa--confirm").style.display = "block";
                }
                return true;
            });
        }
        return true;
    });
}

const hideConfirm = function() {
    document.getElementById("pa--confirm").style.display = "none";
}

const setTotalZero = function() {
    document.getElementById("pa--total").innerText = 0;
}


document.getElementById("pa-copy--word").addEventListener("click", copyToClipboard.bind(null, document.getElementById("pa--word")));
document.getElementById("pa-copy--mean").addEventListener("click", copyToClipboard.bind(null, document.getElementById("pa--mean")));
document.getElementById("pa-clear--all").addEventListener("click", showConfirm.bind(null))
document.getElementById("pa--no").addEventListener("click", hideConfirm.bind(null));
document.getElementById("pa--yes").addEventListener("click", function() {
    clearAll();
    setTotalZero();
    hideConfirm();
    return true;
});