const elementWord = document.getElementById("pa--word"),
    elementMean = document.getElementById("pa--mean");

chrome.storage.sync.get('words', function(data) {
    if (data && data.words && data.words.length > 0) {
        elementWord.innerText = data.words.join(", ");
    } else {
        elementWord.innerText = "Empty";
    }
});

chrome.storage.sync.get('means', function(data) {
    if (data && data.means && data.means.length > 0) {
        elementMean.innerText = data.means.join(", ");
    } else {
        elementMean.innerText = "Empty";
    }
});

const copyToClipboard = function(ele) {
    /* Get the text field */
    const copyText = document.createElement('textarea');
    copyText.setAttribute('readonly', '');
    copyText.style.position = 'absolute';
    copyText.style.left = '-9999px';
    document.body.appendChild(copyText);

    copyText.value = ele.innerText;
    /* Select the text field */
    copyText.select();

    /* Copy the text inside the text field */
    document.execCommand("copy");
    document.body.removeChild(copyText);

    document.getElementById("pa--notification").style.display = "block";
    setTimeout(() => {
        document.getElementById("pa--notification").style.display = "none";
    }, 2000);
    // document.getElementById("pa--notification").style.opacity = 1;
    //return copyText.value;
}


document.getElementById("pa-copy--word").addEventListener("click", copyToClipboard.bind(null, document.getElementById("pa--word")));
document.getElementById("pa-copy--mean").addEventListener("click", copyToClipboard.bind(null, document.getElementById("pa--mean")));