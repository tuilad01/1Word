chrome.runtime.onInstalled.addListener(function() {

    chrome.storage.sync.set({ words: [], means: [] });

    chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
        chrome.declarativeContent.onPageChanged.addRules([{
            conditions: [new chrome.declarativeContent.PageStateMatcher({
                pageUrl: { urlMatches: '.' },
            })],
            actions: [new chrome.declarativeContent.ShowPageAction()]
        }]);
    });

    chrome.contextMenus.create({
        id: "storeword_word_mean",
        title: "Save",
        type: 'normal',
        contexts: ['selection']
    });

    chrome.contextMenus.create({
        id: "storeword_name",
        title: "Name",
        type: 'normal',
        contexts: ['selection']
    });

    chrome.contextMenus.create({
        id: "storeword_mean",
        title: "Mean",
        type: 'normal',
        contexts: ['selection']
    });

    chrome.contextMenus.create({
        id: "storeword_reset",
        title: "Reset store word",
        type: 'normal',
        contexts: ['page']
    });
    // chrome.commands.onCommand.addListener(function(command) {

    // });

});

const showNotificationMessage = function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { commands: "showNotificationMessage" });
        return true;
    });
    return true;
}

const saveWord = function(str) {
    if (!str) return false;

    str = str.trim().toLowerCase();

    chrome.storage.sync.get('words', function(data) {
        if (data && data.words) {
            data.words.push(str);
            chrome.storage.sync.set({ words: data.words });
        }
        return true;
    });
    return true;
}

const saveMean = function(str) {
    if (!str) return false;

    str = str.trim().toLowerCase();

    chrome.storage.sync.get('means', function(data) {
        if (data && data.means) {
            data.means.push(str);
            chrome.storage.sync.set({ means: data.means });
        }
        return true;
    });
    return true;
}

const saveAll = function(str) {
    if (!str) return false;

    const regex = new RegExp(/(.+)[\n\s]VIETNAMESE[\n\s](.+)/, "gmi");
    const arr = regex.exec(str);
    if (arr && arr.length && arr.length === 3) {
        saveWord(arr[1]);
        saveMean(arr[2]);
    }
    return true;
}


chrome.contextMenus.onClicked.addListener(function(info, tab) {
    if (info.menuItemId === "storeword_word_mean") {
        if (info.selectionText) {
            saveAll(info.selectionText);
            showNotificationMessage();
        }
    }

    if (info.menuItemId === "storeword_name") {
        saveWord(info.selectionText);
        showNotificationMessage();
    }

    if (info.menuItemId === "storeword_mean") {
        saveMean(info.selectionText);
        showNotificationMessage();
    }

    if (info.menuItemId === "storeword_reset") {
        chrome.storage.sync.set({ words: [], means: [] });
    }
    return true;
});

chrome.commands.onCommand.addListener(function(command) {
    if (command === "toggle-feature-save") {
        chrome.tabs.executeScript({
            code: "window.getSelection().toString();"
        }, function(selection) {
            if (selection[0]) {
                saveAll(selection[0]);
                showNotificationMessage();
            }
        });
    }

    return true;
});