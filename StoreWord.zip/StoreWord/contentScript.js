const container = document.createElement("DIV");
const notiMessage = document.createElement("DIV");
const para = document.createElement("P");

container.className = "noti--container";
notiMessage.className = "noti--message";

para.innerText = "Saved 💾";

notiMessage.append(para);

container.append(notiMessage);

document.getElementsByTagName("body")[0].append(container);

const showNotificationMessage = function() {
    const elementNotification = document.getElementsByClassName("noti--container")[0];
    if (!elementNotification) return false;

    elementNotification.style.display = "flex";
    setTimeout(() => {
        elementNotification.style.display = "none";
    }, 2000);
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.commands == "showNotificationMessage")
            showNotificationMessage();
        return true;
    });